# FarmWise Weather Prediction App - Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern weather apps like Weather.com and AccuWeather, combined with agricultural dashboard patterns from precision farming platforms. The design emphasizes data visualization and actionable insights for farmers.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Deep Forest Green: 140 30% 25% (primary brand)
- Sky Blue: 210 60% 55% (weather data)
- Earth Brown: 25 25% 35% (grounding element)

**Accent Colors:**
- Warm Orange: 35 80% 60% (alerts/warnings)
- Light Green: 120 40% 70% (positive conditions)

**Background Colors:**
- Light mode: 0 0% 98% (main background)
- Dark mode: 220 15% 12% (main background)

### Typography
**Fonts:** Inter (primary), Roboto Mono (data display)
- Headings: Inter Bold 24px-32px
- Body text: Inter Regular 16px
- Data displays: Roboto Mono 14px-18px

### Layout System
**Spacing:** Consistent 8px, 16px, 24px, 32px grid system
- Card padding: 24px
- Section spacing: 32px
- Component gaps: 16px

## Component Library

### Navigation
- Clean header with FarmWise logo and location selector
- Minimal navigation focusing on current/forecast views

### Weather Cards
- **Current Weather Card**: Large temperature display with location, conditions icon, and key metrics
- **7-Day Forecast Cards**: Compact daily cards showing high/low temps, precipitation chance, and weather icons
- **Advanced Metrics Panel**: Humidity, UV index, wind speed, soil moisture indicators

### Data Visualization
- **Temperature Trend Graph**: Line chart showing 7-day temperature patterns
- **Precipitation Chart**: Bar chart for rainfall predictions
- **Farming Insights Panel**: Color-coded recommendations (planting conditions, frost warnings, harvest timing)

### Interactive Elements
- Location detection button with GPS icon
- Metric toggle switches (Celsius/Fahrenheit, etc.)
- Expandable forecast details

## Farmer-Focused Features

### Agricultural Insights
- **Frost Warning System**: Prominent alerts for temperature drops
- **Planting Conditions**: Green/yellow/red indicators for optimal planting windows
- **Harvest Recommendations**: Weather-based timing suggestions
- **Soil Moisture Index**: Derived from humidity and precipitation data

### Mobile-First Design
- Touch-friendly controls for field use
- Readable text in outdoor lighting conditions
- Quick-access current conditions at the top

## Visual Treatment
- Clean, professional interface prioritizing data clarity
- Weather condition icons: Modern, easily recognizable symbols
- Subtle gradients on cards (sky blue to white for weather cards)
- Strategic use of color for alerts and status indicators

## Images
No large hero image needed. Focus on:
- Weather condition icons (sun, clouds, rain, etc.)
- Small illustrative icons for farming activities
- Background: Subtle agricultural patterns or clean gradients

This design balances modern weather app functionality with farmer-specific needs, ensuring quick access to critical agricultural weather insights.