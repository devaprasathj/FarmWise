import { useState, useCallback } from 'react';

interface LocationData {
  latitude: number;
  longitude: number;
  city?: string;
  state?: string;
  country?: string;
}

interface UseLocationReturn {
  location: LocationData | null;
  isLoading: boolean;
  error: string | null;
  detectLocation: () => void;
}

export function useLocation(): UseLocationReturn {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const detectLocation = useCallback(() => {
    setIsLoading(true);
    setError(null);

    if (!navigator.geolocation) {
      setError('Geolocation is not supported by this browser');
      setIsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        try {
          // todo: remove mock functionality - replace with real reverse geocoding
          // Simulate API call for reverse geocoding
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // Mock location data based on coordinates
          const mockLocationData: LocationData = {
            latitude,
            longitude,
            city: 'Springfield',
            state: 'Illinois',
            country: 'United States'
          };
          
          setLocation(mockLocationData);
          console.log('Location detected:', mockLocationData);
        } catch (err) {
          setError('Failed to get location details');
          console.error('Reverse geocoding error:', err);
        } finally {
          setIsLoading(false);
        }
      },
      (err) => {
        let errorMessage = 'Failed to get location';
        
        switch (err.code) {
          case err.PERMISSION_DENIED:
            errorMessage = 'Location access denied by user';
            break;
          case err.POSITION_UNAVAILABLE:
            errorMessage = 'Location information unavailable';
            break;
          case err.TIMEOUT:
            errorMessage = 'Location request timed out';
            break;
        }
        
        setError(errorMessage);
        setIsLoading(false);
        console.error('Geolocation error:', err);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  }, []);

  return {
    location,
    isLoading,
    error,
    detectLocation
  };
}