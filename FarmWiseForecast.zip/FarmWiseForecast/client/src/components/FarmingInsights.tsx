import { AlertTriangle, CheckCircle, Clock, Sprout, Tractor, Droplets } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface InsightData {
  type: 'frost' | 'planting' | 'harvest' | 'irrigation';
  title: string;
  description: string;
  status: 'optimal' | 'caution' | 'warning';
  action?: string;
}

interface FarmingInsightsProps {
  insights: InsightData[];
  soilMoistureIndex: number;
  growingDegrees: number;
}

const getStatusColor = (status: string) => {
  switch (status) {
    case 'optimal': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    case 'caution': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    case 'warning': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'optimal': return CheckCircle;
    case 'caution': return Clock;
    case 'warning': return AlertTriangle;
    default: return Clock;
  }
};

const getInsightIcon = (type: string) => {
  switch (type) {
    case 'frost': return AlertTriangle;
    case 'planting': return Sprout;
    case 'harvest': return Tractor;
    case 'irrigation': return Droplets;
    default: return Clock;
  }
};

export default function FarmingInsights({ insights, soilMoistureIndex, growingDegrees }: FarmingInsightsProps) {
  return (
    <Card data-testid="card-farming-insights">
      <CardHeader>
        <CardTitle className="flex items-center gap-2" data-testid="title-insights">
          <Sprout className="w-5 h-5 text-green-600" />
          Farming Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4 p-4 bg-muted/30 rounded-md">
          <div className="text-center" data-testid="metric-soil-moisture">
            <p className="text-2xl font-bold text-blue-600">{soilMoistureIndex}%</p>
            <p className="text-sm text-muted-foreground">Soil Moisture Index</p>
          </div>
          <div className="text-center" data-testid="metric-growing-degrees">
            <p className="text-2xl font-bold text-green-600">{growingDegrees}°</p>
            <p className="text-sm text-muted-foreground">Growing Degree Days</p>
          </div>
        </div>

        {/* Insights List */}
        <div className="space-y-3">
          {insights.map((insight, index) => {
            const StatusIcon = getStatusIcon(insight.status);
            const InsightIcon = getInsightIcon(insight.type);
            
            return (
              <Alert key={index} className="hover-elevate" data-testid={`insight-${index}`}>
                <div className="flex items-start gap-3">
                  <InsightIcon className="w-5 h-5 mt-0.5 text-weather-earth" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-foreground" data-testid={`insight-title-${index}`}>
                        {insight.title}
                      </h4>
                      <Badge variant="outline" className={getStatusColor(insight.status)} data-testid={`insight-status-${index}`}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {insight.status}
                      </Badge>
                    </div>
                    <AlertDescription className="text-sm text-muted-foreground" data-testid={`insight-description-${index}`}>
                      {insight.description}
                    </AlertDescription>
                    {insight.action && (
                      <p className="text-sm font-medium text-primary mt-2" data-testid={`insight-action-${index}`}>
                        💡 {insight.action}
                      </p>
                    )}
                  </div>
                </div>
              </Alert>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}