import { Sun, Wind, Droplets, Thermometer, Gauge, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface MetricData {
  label: string;
  value: string;
  unit: string;
  percentage: number;
  icon: any;
  color: string;
  description: string;
}

interface AdvancedMetricsProps {
  uvIndex: number;
  dewPoint: number;
  barometricPressure: number;
  airQuality: number;
  evapotranspiration: number;
  solarRadiation: number;
}

export default function AdvancedMetrics({
  uvIndex,
  dewPoint,
  barometricPressure,
  airQuality,
  evapotranspiration,
  solarRadiation
}: AdvancedMetricsProps) {
  const metrics: MetricData[] = [
    {
      label: 'UV Index',
      value: uvIndex.toString(),
      unit: '',
      percentage: (uvIndex / 11) * 100,
      icon: Sun,
      color: uvIndex > 6 ? 'bg-red-500' : uvIndex > 3 ? 'bg-yellow-500' : 'bg-green-500',
      description: uvIndex > 6 ? 'High - Protection needed' : uvIndex > 3 ? 'Moderate' : 'Low'
    },
    {
      label: 'Dew Point',
      value: dewPoint.toString(),
      unit: '°F',
      percentage: Math.min((dewPoint / 80) * 100, 100),
      icon: Droplets,
      color: 'bg-blue-500',
      description: dewPoint > 65 ? 'Very humid' : dewPoint > 55 ? 'Comfortable' : 'Dry'
    },
    {
      label: 'Pressure',
      value: barometricPressure.toFixed(2),
      unit: 'inHg',
      percentage: ((barometricPressure - 28.0) / (31.0 - 28.0)) * 100,
      icon: Gauge,
      color: 'bg-gray-500',
      description: barometricPressure > 30.2 ? 'High' : barometricPressure < 29.8 ? 'Low' : 'Normal'
    },
    {
      label: 'Air Quality',
      value: airQuality.toString(),
      unit: 'AQI',
      percentage: Math.min((airQuality / 150) * 100, 100),
      icon: Wind,
      color: airQuality > 100 ? 'bg-red-500' : airQuality > 50 ? 'bg-yellow-500' : 'bg-green-500',
      description: airQuality > 100 ? 'Unhealthy' : airQuality > 50 ? 'Moderate' : 'Good'
    },
    {
      label: 'Evapotranspiration',
      value: evapotranspiration.toFixed(1),
      unit: 'in/day',
      percentage: (evapotranspiration / 0.5) * 100,
      icon: Thermometer,
      color: 'bg-orange-500',
      description: evapotranspiration > 0.3 ? 'High water loss' : 'Normal'
    },
    {
      label: 'Solar Radiation',
      value: solarRadiation.toString(),
      unit: 'W/m²',
      percentage: (solarRadiation / 1000) * 100,
      icon: Zap,
      color: 'bg-yellow-500',
      description: solarRadiation > 800 ? 'Intense' : solarRadiation > 400 ? 'Moderate' : 'Low'
    }
  ];

  return (
    <Card data-testid="card-advanced-metrics">
      <CardHeader>
        <CardTitle className="flex items-center gap-2" data-testid="title-metrics">
          <Gauge className="w-5 h-5 text-blue-600" />
          Advanced Metrics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {metrics.map((metric, index) => {
            const IconComponent = metric.icon;
            
            return (
              <div
                key={metric.label}
                className="p-4 bg-card border border-card-border rounded-md hover-elevate"
                data-testid={`metric-${index}`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <IconComponent className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground" data-testid={`metric-label-${index}`}>
                      {metric.label}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold text-foreground" data-testid={`metric-value-${index}`}>
                      {metric.value}
                    </span>
                    <span className="text-sm text-muted-foreground ml-1" data-testid={`metric-unit-${index}`}>
                      {metric.unit}
                    </span>
                  </div>
                </div>
                
                <Progress 
                  value={Math.min(Math.max(metric.percentage, 0), 100)} 
                  className="h-2 mb-2" 
                  data-testid={`metric-progress-${index}`}
                />
                
                <p className="text-xs text-muted-foreground" data-testid={`metric-description-${index}`}>
                  {metric.description}
                </p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}