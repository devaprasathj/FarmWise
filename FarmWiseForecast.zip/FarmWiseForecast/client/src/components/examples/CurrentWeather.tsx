import CurrentWeather from '../CurrentWeather';

export default function CurrentWeatherExample() {
  return (
    <CurrentWeather
      temperature={72}
      condition="Partly Cloudy"
      humidity={68}
      windSpeed={8}
      visibility={10}
      feelsLike={75}
      location="Springfield, IL"
      lastUpdated="2 minutes ago"
    />
  );
}