import Header from '../Header';

export default function HeaderExample() {
  return (
    <Header 
      location="Springfield, IL"
      onLocationDetect={() => console.log('Detect location triggered')}
      isDetecting={false}
    />
  );
}