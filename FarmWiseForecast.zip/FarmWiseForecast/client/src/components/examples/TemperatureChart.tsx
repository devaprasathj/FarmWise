import TemperatureChart from '../TemperatureChart';

export default function TemperatureChartExample() {
  // todo: remove mock functionality
  const mockData = [
    { day: 'Mon', high: 72, low: 58, avg: 65 },
    { day: 'Tue', high: 75, low: 60, avg: 67 },
    { day: 'Wed', high: 68, low: 52, avg: 60 },
    { day: 'Thu', high: 70, low: 55, avg: 62 },
    { day: 'Fri', high: 78, low: 62, avg: 70 },
    { day: 'Sat', high: 74, low: 59, avg: 66 },
    { day: 'Sun', high: 66, low: 50, avg: 58 }
  ];
  
  return <TemperatureChart data={mockData} />;
}