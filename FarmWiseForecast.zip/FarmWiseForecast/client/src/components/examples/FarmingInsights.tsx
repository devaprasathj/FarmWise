import FarmingInsights from '../FarmingInsights';

export default function FarmingInsightsExample() {
  // todo: remove mock functionality
  const mockInsights = [
    {
      type: 'frost' as const,
      title: 'Frost Warning Tonight',
      description: 'Temperature expected to drop to 28°F between 2-6 AM. Protect sensitive crops.',
      status: 'warning' as const,
      action: 'Cover plants or use frost protection methods'
    },
    {
      type: 'planting' as const,
      title: 'Optimal Corn Planting',
      description: 'Soil temperature and moisture levels are ideal for corn planting in next 3 days.',
      status: 'optimal' as const,
      action: 'Plant corn seeds for best germination rates'
    },
    {
      type: 'irrigation' as const,
      title: 'Irrigation Recommended',
      description: 'Soil moisture dropping below optimal levels. Consider irrigation in 2-3 days.',
      status: 'caution' as const
    }
  ];
  
  return (
    <FarmingInsights
      insights={mockInsights}
      soilMoistureIndex={72}
      growingDegrees={145}
    />
  );
}