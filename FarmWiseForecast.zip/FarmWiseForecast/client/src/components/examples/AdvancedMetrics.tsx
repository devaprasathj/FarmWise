import AdvancedMetrics from '../AdvancedMetrics';

export default function AdvancedMetricsExample() {
  return (
    <AdvancedMetrics
      uvIndex={7}
      dewPoint={62}
      barometricPressure={29.92}
      airQuality={45}
      evapotranspiration={0.25}
      solarRadiation={680}
    />
  );
}