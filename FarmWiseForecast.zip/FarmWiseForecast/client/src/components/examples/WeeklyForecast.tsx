import WeeklyForecast from '../WeeklyForecast';

export default function WeeklyForecastExample() {
  const mockForecast = [
    { day: 'Today', date: 'Mar 15', condition: 'Partly Cloudy', high: 72, low: 58, precipitation: 20, humidity: 68 },
    { day: 'Tomorrow', date: 'Mar 16', condition: 'Sunny', high: 75, low: 60, precipitation: 5, humidity: 55 },
    { day: 'Wednesday', date: 'Mar 17', condition: 'Rain', high: 68, low: 52, precipitation: 85, humidity: 82 },
    { day: 'Thursday', date: 'Mar 18', condition: 'Cloudy', high: 70, low: 55, precipitation: 30, humidity: 72 },
    { day: 'Friday', date: 'Mar 19', condition: 'Sunny', high: 78, low: 62, precipitation: 10, humidity: 60 },
    { day: 'Saturday', date: 'Mar 20', condition: 'Partly Cloudy', high: 74, low: 59, precipitation: 25, humidity: 65 },
    { day: 'Sunday', date: 'Mar 21', condition: 'Rain', high: 66, low: 50, precipitation: 75, humidity: 85 }
  ];
  
  return <WeeklyForecast forecast={mockForecast} />;
}