import { Cloud, Sun, CloudRain, CloudSnow } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DayForecast {
  day: string;
  date: string;
  condition: string;
  high: number;
  low: number;
  precipitation: number;
  humidity: number;
}

interface WeeklyForecastProps {
  forecast: DayForecast[];
}

const getWeatherIcon = (condition: string) => {
  const lower = condition.toLowerCase();
  if (lower.includes('sunny') || lower.includes('clear')) return Sun;
  if (lower.includes('rain')) return CloudRain;
  if (lower.includes('snow')) return CloudSnow;
  return Cloud;
};

export default function WeeklyForecast({ forecast }: WeeklyForecastProps) {
  return (
    <Card data-testid="card-weekly-forecast">
      <CardHeader>
        <CardTitle className="flex items-center gap-2" data-testid="title-forecast">
          7-Day Forecast
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {forecast.map((day, index) => {
            const WeatherIcon = getWeatherIcon(day.condition);
            const isToday = index === 0;
            
            return (
              <div
                key={day.day}
                className={`flex items-center justify-between p-3 rounded-md hover-elevate ${
                  isToday ? 'bg-primary/5 border border-primary/20' : 'hover:bg-muted/50'
                }`}
                data-testid={`forecast-day-${index}`}
              >
                <div className="flex items-center gap-3 flex-1">
                  <WeatherIcon className="w-8 h-8 text-weather-sky" data-testid={`icon-day-${index}`} />
                  <div>
                    <p className={`font-medium ${isToday ? 'text-primary' : 'text-foreground'}`} data-testid={`text-day-${index}`}>
                      {isToday ? 'Today' : day.day}
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid={`text-date-${index}`}>{day.date}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Precip</p>
                    <p className="font-medium text-blue-600" data-testid={`text-precip-${index}`}>{day.precipitation}%</p>
                  </div>
                  
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Humidity</p>
                    <p className="font-medium" data-testid={`text-humidity-${index}`}>{day.humidity}%</p>
                  </div>
                  
                  <div className="text-right min-w-[80px]">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-foreground" data-testid={`text-high-${index}`}>{day.high}°</span>
                      <span className="text-muted-foreground" data-testid={`text-low-${index}`}>{day.low}°</span>
                    </div>
                    <p className="text-xs text-muted-foreground" data-testid={`text-condition-${index}`}>{day.condition}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}