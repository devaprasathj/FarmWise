import { Cloud, Sun, CloudRain, Wind, Droplets, Eye, Thermometer } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface CurrentWeatherProps {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
  feelsLike: number;
  location: string;
  lastUpdated: string;
}

const getWeatherIcon = (condition: string) => {
  const lower = condition.toLowerCase();
  if (lower.includes('sunny') || lower.includes('clear')) return Sun;
  if (lower.includes('rain')) return CloudRain;
  return Cloud;
};

const getConditionColor = (condition: string) => {
  const lower = condition.toLowerCase();
  if (lower.includes('sunny') || lower.includes('clear')) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
  if (lower.includes('rain')) return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
  return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
};

export default function CurrentWeather({
  temperature,
  condition,
  humidity,
  windSpeed,
  visibility,
  feelsLike,
  location,
  lastUpdated
}: CurrentWeatherProps) {
  const WeatherIcon = getWeatherIcon(condition);
  
  return (
    <Card className="hover-elevate" data-testid="card-current-weather">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-muted-foreground" data-testid="text-location">{location}</p>
            <p className="text-xs text-muted-foreground" data-testid="text-updated">Updated {lastUpdated}</p>
          </div>
          <Badge variant="secondary" className={getConditionColor(condition)} data-testid="badge-condition">
            {condition}
          </Badge>
        </div>
        
        <div className="flex items-center gap-6 mb-6">
          <WeatherIcon className="w-16 h-16 text-weather-sky" data-testid="icon-weather" />
          <div>
            <div className="text-5xl font-bold text-foreground" data-testid="text-temperature">
              {temperature}°
            </div>
            <p className="text-muted-foreground" data-testid="text-feels-like">
              Feels like {feelsLike}°
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-2" data-testid="metric-humidity">
            <Droplets className="w-4 h-4 text-blue-500" />
            <div>
              <p className="text-sm font-medium">{humidity}%</p>
              <p className="text-xs text-muted-foreground">Humidity</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2" data-testid="metric-wind">
            <Wind className="w-4 h-4 text-gray-500" />
            <div>
              <p className="text-sm font-medium">{windSpeed} mph</p>
              <p className="text-xs text-muted-foreground">Wind</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2" data-testid="metric-visibility">
            <Eye className="w-4 h-4 text-green-500" />
            <div>
              <p className="text-sm font-medium">{visibility} mi</p>
              <p className="text-xs text-muted-foreground">Visibility</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2" data-testid="metric-pressure">
            <Thermometer className="w-4 h-4 text-red-500" />
            <div>
              <p className="text-sm font-medium">29.92"</p>
              <p className="text-xs text-muted-foreground">Pressure</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}