import { MapPin, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  location?: string;
  onLocationDetect?: () => void;
  isDetecting?: boolean;
}

export default function Header({ location = "Detecting location...", onLocationDetect, isDetecting = false }: HeaderProps) {
  return (
    <header className="bg-card border-b border-card-border px-6 py-4" data-testid="header-main">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-md flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg" data-testid="text-logo">FW</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground" data-testid="text-title">FarmWise</h1>
            <p className="text-sm text-muted-foreground" data-testid="text-subtitle">Weather Prediction for Farmers</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-foreground" data-testid="location-display">
            <MapPin className="w-4 h-4" />
            <span className="text-sm font-medium">{location}</span>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onLocationDetect}
            disabled={isDetecting}
            data-testid="button-location"
            className="hover-elevate"
          >
            <Navigation className={`w-4 h-4 mr-2 ${isDetecting ? 'animate-spin' : ''}`} />
            {isDetecting ? 'Detecting...' : 'Detect Location'}
          </Button>
        </div>
      </div>
    </header>
  );
}