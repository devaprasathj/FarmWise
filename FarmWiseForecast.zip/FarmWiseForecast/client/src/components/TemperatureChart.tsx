import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';

interface TemperatureData {
  day: string;
  high: number;
  low: number;
  avg: number;
}

interface TemperatureChartProps {
  data: TemperatureData[];
}

export default function TemperatureChart({ data }: TemperatureChartProps) {
  const maxTemp = Math.max(...data.map(d => d.high));
  const minTemp = Math.min(...data.map(d => d.low));
  const range = maxTemp - minTemp;
  
  const getPosition = (temp: number) => {
    return ((maxTemp - temp) / range) * 100;
  };

  return (
    <Card data-testid="card-temperature-chart">
      <CardHeader>
        <CardTitle className="flex items-center gap-2" data-testid="title-temperature-chart">
          <TrendingUp className="w-5 h-5 text-green-600" />
          7-Day Temperature Trend
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative h-48 mb-4">
          {/* Temperature scale */}
          <div className="absolute left-0 top-0 bottom-0 w-8 flex flex-col justify-between text-xs text-muted-foreground">
            <span data-testid="temp-scale-max">{maxTemp}°</span>
            <span data-testid="temp-scale-mid">{Math.round((maxTemp + minTemp) / 2)}°</span>
            <span data-testid="temp-scale-min">{minTemp}°</span>
          </div>
          
          {/* Chart area */}
          <div className="ml-10 h-full relative bg-gradient-to-b from-red-50 via-yellow-50 to-blue-50 dark:from-red-950/20 dark:via-yellow-950/20 dark:to-blue-950/20 rounded-md">
            {/* High temperature line */}
            <svg className="absolute inset-0 w-full h-full" data-testid="temp-chart-svg">
              <polyline
                fill="none"
                stroke="rgb(239, 68, 68)"
                strokeWidth="3"
                points={data.map((d, i) => 
                  `${(i / (data.length - 1)) * 100}%,${getPosition(d.high)}%`
                ).join(' ')}
                data-testid="line-high-temp"
              />
              <polyline
                fill="none"
                stroke="rgb(59, 130, 246)"
                strokeWidth="3"
                points={data.map((d, i) => 
                  `${(i / (data.length - 1)) * 100}%,${getPosition(d.low)}%`
                ).join(' ')}
                data-testid="line-low-temp"
              />
              
              {/* Data points */}
              {data.map((d, i) => (
                <g key={i}>
                  <circle
                    cx={`${(i / (data.length - 1)) * 100}%`}
                    cy={`${getPosition(d.high)}%`}
                    r="4"
                    fill="rgb(239, 68, 68)"
                    data-testid={`point-high-${i}`}
                  />
                  <circle
                    cx={`${(i / (data.length - 1)) * 100}%`}
                    cy={`${getPosition(d.low)}%`}
                    r="4"
                    fill="rgb(59, 130, 246)"
                    data-testid={`point-low-${i}`}
                  />
                </g>
              ))}
            </svg>
          </div>
        </div>
        
        {/* Day labels */}
        <div className="ml-10 flex justify-between text-sm text-muted-foreground">
          {data.map((d, i) => (
            <span key={i} data-testid={`chart-day-${i}`}>
              {d.day}
            </span>
          ))}
        </div>
        
        {/* Legend */}
        <div className="flex items-center justify-center gap-6 mt-4 pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full" data-testid="legend-high"></div>
            <span className="text-sm text-muted-foreground">High Temperature</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full" data-testid="legend-low"></div>
            <span className="text-sm text-muted-foreground">Low Temperature</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}