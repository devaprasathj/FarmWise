import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import CurrentWeather from '@/components/CurrentWeather';
import WeeklyForecast from '@/components/WeeklyForecast';
import FarmingInsights from '@/components/FarmingInsights';
import AdvancedMetrics from '@/components/AdvancedMetrics';
import TemperatureChart from '@/components/TemperatureChart';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useLocation } from '@/hooks/useLocation';

export default function Home() {
  const { location, isLoading, detectLocation } = useLocation();
  const [lastUpdated, setLastUpdated] = useState('2 minutes ago');

  // todo: remove mock functionality
  const mockWeeklyForecast = [
    { day: 'Today', date: 'Mar 15', condition: 'Partly Cloudy', high: 72, low: 58, precipitation: 20, humidity: 68 },
    { day: 'Tomorrow', date: 'Mar 16', condition: 'Sunny', high: 75, low: 60, precipitation: 5, humidity: 55 },
    { day: 'Wednesday', date: 'Mar 17', condition: 'Rain', high: 68, low: 52, precipitation: 85, humidity: 82 },
    { day: 'Thursday', date: 'Mar 18', condition: 'Cloudy', high: 70, low: 55, precipitation: 30, humidity: 72 },
    { day: 'Friday', date: 'Mar 19', condition: 'Sunny', high: 78, low: 62, precipitation: 10, humidity: 60 },
    { day: 'Saturday', date: 'Mar 20', condition: 'Partly Cloudy', high: 74, low: 59, precipitation: 25, humidity: 65 },
    { day: 'Sunday', date: 'Mar 21', condition: 'Rain', high: 66, low: 50, precipitation: 75, humidity: 85 }
  ];

  const mockInsights = [
    {
      type: 'frost' as const,
      title: 'Frost Warning Tonight',
      description: 'Temperature expected to drop to 28°F between 2-6 AM. Protect sensitive crops.',
      status: 'warning' as const,
      action: 'Cover plants or use frost protection methods'
    },
    {
      type: 'planting' as const,
      title: 'Optimal Corn Planting',
      description: 'Soil temperature and moisture levels are ideal for corn planting in next 3 days.',
      status: 'optimal' as const,
      action: 'Plant corn seeds for best germination rates'
    },
    {
      type: 'irrigation' as const,
      title: 'Irrigation Recommended',
      description: 'Soil moisture dropping below optimal levels. Consider irrigation in 2-3 days.',
      status: 'caution' as const
    }
  ];

  const mockTemperatureData = [
    { day: 'Mon', high: 72, low: 58, avg: 65 },
    { day: 'Tue', high: 75, low: 60, avg: 67 },
    { day: 'Wed', high: 68, low: 52, avg: 60 },
    { day: 'Thu', high: 70, low: 55, avg: 62 },
    { day: 'Fri', high: 78, low: 62, avg: 70 },
    { day: 'Sat', high: 74, low: 59, avg: 66 },
    { day: 'Sun', high: 66, low: 50, avg: 58 }
  ];

  useEffect(() => {
    // Auto-detect location on page load
    detectLocation();
  }, [detectLocation]);

  const locationDisplay = location 
    ? `${location.city}, ${location.state}`
    : isLoading 
    ? "Detecting location..." 
    : "Location not detected";

  return (
    <div className="min-h-screen bg-background" data-testid="page-home">
      <Header 
        location={locationDisplay}
        onLocationDetect={detectLocation}
        isDetecting={isLoading}
      />
      
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>
      
      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Current Weather */}
        <CurrentWeather
          temperature={72}
          condition="Partly Cloudy"
          humidity={68}
          windSpeed={8}
          visibility={10}
          feelsLike={75}
          location={locationDisplay}
          lastUpdated={lastUpdated}
        />
        
        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Forecast and Chart */}
          <div className="lg:col-span-2 space-y-8">
            <WeeklyForecast forecast={mockWeeklyForecast} />
            <TemperatureChart data={mockTemperatureData} />
          </div>
          
          {/* Right Column - Insights and Metrics */}
          <div className="space-y-8">
            <FarmingInsights
              insights={mockInsights}
              soilMoistureIndex={72}
              growingDegrees={145}
            />
            <AdvancedMetrics
              uvIndex={7}
              dewPoint={62}
              barometricPressure={29.92}
              airQuality={45}
              evapotranspiration={0.25}
              solarRadiation={680}
            />
          </div>
        </div>
      </main>
    </div>
  );
}