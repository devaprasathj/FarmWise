// FarmWise Weather Application
class FarmWiseApp {
    constructor() {
        this.currentLocation = null;
        this.isDetectingLocation = false;
        this.theme = localStorage.getItem('farmwise-theme') || 'light';
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.applyTheme();
        this.loadMockData();
        this.detectLocationOnLoad();
    }
    
    setupEventListeners() {
        // Location detection
        document.getElementById('detect-location-btn').addEventListener('click', () => {
            this.detectLocation();
        });
        
        // Theme toggle
        document.getElementById('theme-toggle').addEventListener('click', () => {
            this.toggleTheme();
        });
    }
    
    detectLocationOnLoad() {
        // Auto-detect location when page loads
        setTimeout(() => {
            this.detectLocation();
        }, 1000);
    }
    
    detectLocation() {
        if (this.isDetectingLocation) return;
        
        this.isDetectingLocation = true;
        this.updateLocationButton(true);
        
        if (!navigator.geolocation) {
            this.handleLocationError('Geolocation not supported');
            return;
        }
        
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                this.handleLocationSuccess(latitude, longitude);
            },
            (error) => {
                this.handleLocationError(this.getLocationErrorMessage(error));
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 300000
            }
        );
    }
    
    handleLocationSuccess(lat, lon) {
        // Simulate reverse geocoding with mock data
        setTimeout(() => {
            const mockLocation = {
                latitude: lat,
                longitude: lon,
                city: 'Springfield',
                state: 'Illinois',
                country: 'United States'
            };
            
            this.currentLocation = mockLocation;
            this.updateLocationDisplay(`${mockLocation.city}, ${mockLocation.state}`);
            this.updateLocationButton(false);
            this.isDetectingLocation = false;
            
            console.log('Location detected:', mockLocation);
        }, 1500);
    }
    
    handleLocationError(errorMessage) {
        console.error('Location error:', errorMessage);
        this.updateLocationDisplay('Location unavailable');
        this.updateLocationButton(false);
        this.isDetectingLocation = false;
    }
    
    getLocationErrorMessage(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                return 'Location access denied';
            case error.POSITION_UNAVAILABLE:
                return 'Location unavailable';
            case error.TIMEOUT:
                return 'Location request timeout';
            default:
                return 'Failed to get location';
        }
    }
    
    updateLocationDisplay(locationText) {
        document.getElementById('location-text').textContent = locationText;
        document.getElementById('weather-location').textContent = locationText;
    }
    
    updateLocationButton(isDetecting) {
        const btn = document.getElementById('detect-location-btn');
        const btnText = document.getElementById('location-btn-text');
        
        btn.disabled = isDetecting;
        btnText.textContent = isDetecting ? 'Detecting...' : 'Detect Location';
        
        if (isDetecting) {
            btn.classList.add('loading');
        } else {
            btn.classList.remove('loading');
        }
    }
    
    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        this.applyTheme();
        localStorage.setItem('farmwise-theme', this.theme);
    }
    
    applyTheme() {
        document.documentElement.setAttribute('data-theme', this.theme);
    }
    
    loadMockData() {
        this.renderForecast();
        this.renderInsights();
        this.renderAdvancedMetrics();
        this.renderTemperatureChart();
        this.updateLastUpdated();
    }
    
    renderForecast() {
        const mockForecast = [
            { day: 'Today', date: 'Mar 15', condition: 'Partly Cloudy', high: 72, low: 58, precipitation: 20, humidity: 68 },
            { day: 'Tomorrow', date: 'Mar 16', condition: 'Sunny', high: 75, low: 60, precipitation: 5, humidity: 55 },
            { day: 'Wednesday', date: 'Mar 17', condition: 'Rain', high: 68, low: 52, precipitation: 85, humidity: 82 },
            { day: 'Thursday', date: 'Mar 18', condition: 'Cloudy', high: 70, low: 55, precipitation: 30, humidity: 72 },
            { day: 'Friday', date: 'Mar 19', condition: 'Sunny', high: 78, low: 62, precipitation: 10, humidity: 60 },
            { day: 'Saturday', date: 'Mar 20', condition: 'Partly Cloudy', high: 74, low: 59, precipitation: 25, humidity: 65 },
            { day: 'Sunday', date: 'Mar 21', condition: 'Rain', high: 66, low: 50, precipitation: 75, humidity: 85 }
        ];
        
        const forecastList = document.getElementById('forecast-list');
        forecastList.innerHTML = '';
        
        mockForecast.forEach((day, index) => {
            const isToday = index === 0;
            const forecastItem = document.createElement('div');
            forecastItem.className = `forecast-item ${isToday ? 'today' : ''}`;
            
            forecastItem.innerHTML = `
                <div class="forecast-info">
                    <div class="forecast-icon">
                        ${this.getWeatherIcon(day.condition)}
                    </div>
                    <div>
                        <div class="forecast-day">${isToday ? 'Today' : day.day}</div>
                        <div class="forecast-date">${day.date}</div>
                    </div>
                </div>
                <div class="forecast-details">
                    <div class="forecast-metric">
                        <div class="forecast-metric-value">${day.precipitation}%</div>
                        <div class="forecast-metric-label">Precip</div>
                    </div>
                    <div class="forecast-metric">
                        <div class="forecast-metric-value">${day.humidity}%</div>
                        <div class="forecast-metric-label">Humidity</div>
                    </div>
                    <div class="forecast-temps">
                        <span class="forecast-high">${day.high}°</span>
                        <span class="forecast-low">${day.low}°</span>
                        <div class="forecast-condition">${day.condition}</div>
                    </div>
                </div>
            `;
            
            forecastList.appendChild(forecastItem);
        });
    }
    
    renderInsights() {
        const mockInsights = [
            {
                type: 'frost',
                title: 'Frost Warning Tonight',
                description: 'Temperature expected to drop to 28°F between 2-6 AM. Protect sensitive crops.',
                status: 'warning',
                action: 'Cover plants or use frost protection methods'
            },
            {
                type: 'planting',
                title: 'Optimal Corn Planting',
                description: 'Soil temperature and moisture levels are ideal for corn planting in next 3 days.',
                status: 'optimal',
                action: 'Plant corn seeds for best germination rates'
            },
            {
                type: 'irrigation',
                title: 'Irrigation Recommended',
                description: 'Soil moisture dropping below optimal levels. Consider irrigation in 2-3 days.',
                status: 'caution'
            }
        ];
        
        const insightsList = document.getElementById('insights-list');
        insightsList.innerHTML = '';
        
        mockInsights.forEach((insight) => {
            const insightItem = document.createElement('div');
            insightItem.className = 'insight-item';
            
            insightItem.innerHTML = `
                <div class="insight-header">
                    <div class="insight-icon">
                        ${this.getInsightIcon(insight.type)}
                    </div>
                    <div class="insight-title">${insight.title}</div>
                    <div class="insight-status status-${insight.status}">${insight.status}</div>
                </div>
                <div class="insight-description">${insight.description}</div>
                ${insight.action ? `<div class="insight-action">💡 ${insight.action}</div>` : ''}
            `;
            
            insightsList.appendChild(insightItem);
        });
    }
    
    renderAdvancedMetrics() {
        const metrics = [
            { name: 'UV Index', value: 7, unit: '', max: 11, description: 'High - Protection needed' },
            { name: 'Dew Point', value: 62, unit: '°F', max: 80, description: 'Comfortable' },
            { name: 'Pressure', value: 29.92, unit: 'inHg', max: 31, description: 'Normal' },
            { name: 'Air Quality', value: 45, unit: 'AQI', max: 150, description: 'Good' },
            { name: 'Evapotranspiration', value: 0.25, unit: 'in/day', max: 0.5, description: 'Normal' },
            { name: 'Solar Radiation', value: 680, unit: 'W/m²', max: 1000, description: 'Moderate' }
        ];
        
        const metricsContainer = document.getElementById('advanced-metrics');
        metricsContainer.innerHTML = '';
        
        metrics.forEach((metric) => {
            const percentage = Math.min((metric.value / metric.max) * 100, 100);
            
            const metricElement = document.createElement('div');
            metricElement.className = 'advanced-metric';
            
            metricElement.innerHTML = `
                <div class="metric-header">
                    <div class="metric-name">
                        <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                            <circle cx="12" cy="12" r="10"/>
                        </svg>
                        ${metric.name}
                    </div>
                    <div>
                        <span class="metric-value-large">${metric.value}</span>
                        <span class="metric-unit">${metric.unit}</span>
                    </div>
                </div>
                <div class="metric-bar">
                    <div class="metric-progress" style="width: ${percentage}%"></div>
                </div>
                <div class="metric-description">${metric.description}</div>
            `;
            
            metricsContainer.appendChild(metricElement);
        });
    }
    
    renderTemperatureChart() {
        const canvas = document.getElementById('temperature-chart');
        const ctx = canvas.getContext('2d');
        
        const data = [
            { day: 'Mon', high: 72, low: 58 },
            { day: 'Tue', high: 75, low: 60 },
            { day: 'Wed', high: 68, low: 52 },
            { day: 'Thu', high: 70, low: 55 },
            { day: 'Fri', high: 78, low: 62 },
            { day: 'Sat', high: 74, low: 59 },
            { day: 'Sun', high: 66, low: 50 }
        ];
        
        const maxTemp = Math.max(...data.map(d => d.high));
        const minTemp = Math.min(...data.map(d => d.low));
        const range = maxTemp - minTemp;
        
        const width = canvas.width;
        const height = canvas.height;
        const padding = 40;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Set up colors based on theme
        const isLight = this.theme === 'light';
        const lineColor = isLight ? '#ef4444' : '#f87171';
        const lowLineColor = isLight ? '#3b82f6' : '#60a5fa';
        const textColor = isLight ? '#374151' : '#d1d5db';
        
        ctx.strokeStyle = lineColor;
        ctx.fillStyle = textColor;
        ctx.font = '12px Inter';
        
        // Draw temperature lines
        const pointSpacing = (width - padding * 2) / (data.length - 1);
        
        // High temperature line
        ctx.beginPath();
        data.forEach((point, index) => {
            const x = padding + index * pointSpacing;
            const y = padding + ((maxTemp - point.high) / range) * (height - padding * 2);
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        ctx.stroke();
        
        // Low temperature line
        ctx.strokeStyle = lowLineColor;
        ctx.beginPath();
        data.forEach((point, index) => {
            const x = padding + index * pointSpacing;
            const y = padding + ((maxTemp - point.low) / range) * (height - padding * 2);
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        ctx.stroke();
        
        // Draw points and labels
        data.forEach((point, index) => {
            const x = padding + index * pointSpacing;
            const highY = padding + ((maxTemp - point.high) / range) * (height - padding * 2);
            const lowY = padding + ((maxTemp - point.low) / range) * (height - padding * 2);
            
            // High temperature point
            ctx.fillStyle = lineColor;
            ctx.beginPath();
            ctx.arc(x, highY, 4, 0, 2 * Math.PI);
            ctx.fill();
            
            // Low temperature point
            ctx.fillStyle = lowLineColor;
            ctx.beginPath();
            ctx.arc(x, lowY, 4, 0, 2 * Math.PI);
            ctx.fill();
            
            // Day label
            ctx.fillStyle = textColor;
            ctx.textAlign = 'center';
            ctx.fillText(point.day, x, height - 10);
        });
        
        // Legend
        ctx.textAlign = 'left';
        ctx.fillStyle = lineColor;
        ctx.fillRect(width - 150, 20, 12, 12);
        ctx.fillStyle = textColor;
        ctx.fillText('High', width - 130, 30);
        
        ctx.fillStyle = lowLineColor;
        ctx.fillRect(width - 150, 40, 12, 12);
        ctx.fillStyle = textColor;
        ctx.fillText('Low', width - 130, 50);
    }
    
    updateLastUpdated() {
        const now = new Date();
        const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        document.getElementById('last-updated').textContent = `Updated at ${timeString}`;
    }
    
    getWeatherIcon(condition) {
        const lower = condition.toLowerCase();
        if (lower.includes('sunny') || lower.includes('clear')) {
            return `<svg viewBox="0 0 24 24" fill="currentColor">
                <circle cx="12" cy="12" r="4"/>
                <path d="m12 2 3 10L12 22l-3-10z"/>
            </svg>`;
        }
        if (lower.includes('rain')) {
            return `<svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 0 1 0 9Z"/>
                <path d="M12 12v9"/>
                <path d="m8 15 4 4 4-4"/>
            </svg>`;
        }
        return `<svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 0 1 0 9Z"/>
        </svg>`;
    }
    
    getInsightIcon(type) {
        switch (type) {
            case 'frost':
                return `<svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2v20M17 7l-5 5-5-5M7 17l5-5 5 5"/>
                </svg>`;
            case 'planting':
                return `<svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2a2 2 0 0 1 2 2c0 1.02-.47 1.94-1.22 2.56L17 9.67V7a1 1 0 0 1 2 0v4.09"/>
                </svg>`;
            case 'irrigation':
                return `<svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 3v10l9-9-9 9z"/>
                </svg>`;
            default:
                return `<svg viewBox="0 0 24 24" fill="currentColor">
                    <circle cx="12" cy="12" r="10"/>
                </svg>`;
        }
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new FarmWiseApp();
});